<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
//Math functions

//Ceil
echo ceil(1.50) . "<br>";

//Floor
echo floor(1.50) . "<br>";

//Round
echo round(0.54335, 4) . "<br>";

echo exp(4);

?>
</body>
</html>
