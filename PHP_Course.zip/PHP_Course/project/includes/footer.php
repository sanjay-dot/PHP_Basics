</body>
<footer>
<p>This is my footer of the login and register form</p>
</footer>
</html>
