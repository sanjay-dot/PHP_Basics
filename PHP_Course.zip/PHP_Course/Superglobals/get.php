<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
//GET
// Data will be visible in the URL

?>

<form action="get.php" method="get">
    <input type="text" name="name">
    <input type="password" name="password">
    <button type="submit">SUBMIT</button>
</form>

</body>
</html>
