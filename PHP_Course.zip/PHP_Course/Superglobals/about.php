<?php
include 'contact.php';


?>

<h1>
<?php
    if (isset($_POST['submit'])) {
        echo "Form is processed on about";
    }
?>
</h1>
