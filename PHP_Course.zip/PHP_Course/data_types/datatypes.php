<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
//Integer = Numeric values
//Floating point or Float = Decimal
//String
//Booleans
//Array
//Object
//Resource
//Null

$age = 24;
echo "My age is: ". $age;

echo "<br>";

$price = 10.5;
echo "The price is: ". $price;

echo "<br>";

$name = "Dary";
echo "My name is " . $name;

echo "<br>";

$is_allowed = true;
echo $is_allowed;

echo "<br>";
$x = "Hello world";
$x = null;
echo $x;
$y;

?>
</body>
</html>
