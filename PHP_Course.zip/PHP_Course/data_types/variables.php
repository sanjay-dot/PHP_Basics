<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
//VARIABLES
// Is a symbol or name that stands for a value

/*$name = "Dary";


echo "My name is " . $name . "<br>";

echo $name . " is 24 years old" . "<br>"; */


//Variable names
//Variable name starts with a letter A-Z a-z, underscore (_), followed by any number of letters, numbers, or underscores.

$name = "Daryy"; // Valid
$Name = "Dary"; // Valid
//$9name = "Dary"; // Invalid ; starts with a number
$_name = "Dary"; //Valid
$_9name = "Dary"; //Valid

echo $_9name;

?>
</body>
</html>
