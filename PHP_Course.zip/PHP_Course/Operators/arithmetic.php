<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
// Arithmetic operators
// + - * / %

$x = 6;
$y = 3;

echo $x % $y;

?>
</body>
</html>
