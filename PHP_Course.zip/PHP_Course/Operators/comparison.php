<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
//Comparison operators
// <   --- Less than
// >   --- Greater than
// <=  --- Less than or equal to
// >=  --- Greater than or equal to
// === --- Equal to
// !== --- Not equal to

$x = 11;
$y = 12;

if ($x !== $y) {
    echo "True!";
} else {
    echo "False!";
}

?>
</body>
</html>
