<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
//Logical operators
// And  --- Both X and Y are true
// &&   --- Both X and Y are true
// Or   --- Either X or Y are true
// ||   --- Either X or Y are true
// Xor  --- Either X or Y are true, not both
// !    --- True if X is not true
// 1 = True - 0 = False

$x = 1;
$y = 10;

if (!$x == $y && 1 == 1) {
    echo "True!";
} else {
    echo "False!";
}


?>
</body>
</html>
