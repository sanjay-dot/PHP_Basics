<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
// Assignment operators
//  +=  --- Add and assign
//  -=  --- Subtract and assign
//  *=  --- Multiply and assign
//  /=  --- Divide and assign
//  .=  --- Concatenate and assign

$x = 5;
$x /= 5;

echo $x += 5;

$str = "Dary is a old man";
$str .= " because he is 24 years old!";

echo "<br>";
echo $str;

?>
</body>
</html>
