<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
//Camel case
//Every word after the first one is a capital
//myFunction();

//Lower case
//All lowercase, underscore inbetween
//my_function();

//Pascal case
//Every word is capitalized
//MyFunction();

function myFunction() {
    $x = "Hello!";
    echo $x;
}

myFunction();


?>
</body>
</html>
