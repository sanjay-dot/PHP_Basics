<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
//Constants
//Function - define()
//Keyword - CONST

//Define
//Constants are always in uppercase
//Name has the same rules as variables

define("COMPANY_NAME", "Apple");

echo COMPANY_NAME;

//CONST
const MY_NAME = "Dary";
echo MY_NAME;
?>
</body>
</html>
