<?php
function introduction() {
    echo "Hello user!";
}
?>
