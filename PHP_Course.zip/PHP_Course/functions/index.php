<?php
    include 'includes/head.php';
    include 'includes/header.php';
?>


<h1><?php introduction(); ?></h1>

<?php
    include 'includes/footer.php';
    // Include - path is wrong - we only get a warning
    // Require - Path the wrong - the script will stop
?>
