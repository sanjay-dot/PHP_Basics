<?php
    include 'includes/head.php';
    include 'includes/header.php';
?>


<h1>About!</h1>

<?php
    include 'includes/footer.php';
?>
