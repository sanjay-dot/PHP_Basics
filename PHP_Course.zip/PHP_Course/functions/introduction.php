<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
//Functions

// A function is a blck of code written in a program to perform some specific task.


//Two major types of functions
//Built-in function
//User-defined function

//Why should you use functions?
// 1. Reuseability
// 2. Easy for error detection
// 3. Easily maintained

echo "Hello earth";


?>
</body>
</html>
