<?php
    include 'includes/head.php';
    include 'includes/header.php';
?>


<h1>Contact!</h1>

<?php
    include 'includes/footer.php';
?>
